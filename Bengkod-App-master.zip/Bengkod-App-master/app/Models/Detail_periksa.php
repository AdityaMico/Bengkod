<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Detail_periksa extends Model
{
    //
}
